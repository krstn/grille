<?
include 'header.php';
?>
            
            <div id="menu">
                <div class="column">
                    <img src="images/menu/menu1.jpg" />
                    <img src="images/menu/menu2.jpg" />
                </div>
                <div class="column">
                    <img src="images/menu/menu3.jpg" />
					<img src="images/menu/menu3.jpg" />
                </div>
            </div>
        </div>
		
        </center>
    </body>
</html>
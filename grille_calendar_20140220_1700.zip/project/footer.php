        </div>       
        <div id="footer">
            <div id="copyright">
                <img src="images/footer_logo.png" /></br>
                ©2014 Grill Guru
            </div>
        </div>
        </center>
    </body>
</html>
<?php
$dbUser="root";
		$dbPass="";
		$dbName="grille";
		$dbHost=("127.0.0.1");
?>
			<footer>
				<span> � 2013 CVKC AUTO PARTS &#153. All rights reserved.  
				<p> CVKC AUTO PARTS is not responsible for content on external web sites. </p> </span>
			</footer>
		</div>
		</center>
		
	</body>
</html>
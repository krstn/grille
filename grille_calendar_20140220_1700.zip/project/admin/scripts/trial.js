var x = 14;
alert(x);
